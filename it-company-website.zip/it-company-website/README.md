# IT Company Website - Complete Deployment Guide

## 📁 Your Website Files

You have 3 files that make up your website:

```
it-company-website/
├── index.html    ← The content & structure
├── style.css     ← The design & styling  
└── script.js     ← The interactivity
```

---

## 🚀 STEP-BY-STEP DEPLOYMENT GUIDE

### Option A: GitHub Pages (FREE - Recommended for Beginners)

#### Step 1: Create a GitHub Account
1. Go to https://github.com
2. Click "Sign Up" and create an account
3. Verify your email

#### Step 2: Create a New Repository
1. Click the "+" icon (top right) → "New repository"
2. Name it: `my-website` (or any name)
3. Make sure "Public" is selected
4. Check "Add a README file"
5. Click "Create repository"

#### Step 3: Upload Your Files
1. In your repository, click "Add file" → "Upload files"
2. Drag and drop all 3 files (index.html, style.css, script.js)
3. Click "Commit changes"

#### Step 4: Enable GitHub Pages
1. Go to repository "Settings" (tab at top)
2. Scroll down to "Pages" in left sidebar
3. Under "Source", select "main" branch
4. Click "Save"
5. Wait 2-3 minutes, then refresh
6. You'll see: "Your site is live at https://yourusername.github.io/my-website"

#### Step 5: Connect Your GoDaddy Domain
1. In GitHub Pages settings, under "Custom domain", enter your domain (e.g., `yourcompany.com`)
2. Click "Save"

Now go to GoDaddy:
1. Log into GoDaddy → Go to "My Products" → "DNS"
2. Delete any existing A records
3. Add these A records (Type: A, Name: @):
   - 185.199.108.153
   - 185.199.109.153
   - 185.199.110.153
   - 185.199.111.153
4. Add a CNAME record:
   - Type: CNAME
   - Name: www
   - Value: yourusername.github.io
5. Wait 24-48 hours for DNS to update

---

### Option B: Netlify (FREE - Easiest Drag & Drop)

#### Step 1: Go to Netlify
1. Visit https://netlify.com
2. Sign up with GitHub, Google, or Email

#### Step 2: Deploy Your Site
1. On the dashboard, find "Sites" section
2. Drag and drop your entire website folder onto the page
3. Wait for deployment (30 seconds)
4. You get a URL like: `random-name-123.netlify.app`

#### Step 3: Connect Your GoDaddy Domain
1. In Netlify, go to "Domain settings" → "Add custom domain"
2. Enter your domain (e.g., `yourcompany.com`)
3. Click "Verify"

Now go to GoDaddy:
1. Log into GoDaddy → Go to "My Products" → "DNS"
2. Change your nameservers to Netlify's:
   - dns1.p01.nsone.net
   - dns2.p01.nsone.net
   - dns3.p01.nsone.net
   - dns4.p01.nsone.net
3. Wait 24-48 hours for DNS to update

---

## 🎨 HOW TO CUSTOMIZE YOUR WEBSITE

### Change Company Name
In `index.html`, find and replace "TechSolutions" with your company name.

### Change Colors
In `style.css`, find the `:root` section at the top:
```css
:root {
    --primary-color: #2563eb;    /* Main blue color */
    --secondary-color: #0f172a;  /* Dark color */
}
```
Replace `#2563eb` with your brand color. Use https://colorhunt.co for ideas.

### Change Contact Information
In `index.html`, search for the contact section and update:
- Address
- Phone number
- Email
- Working hours

### Change Images
Replace the image URLs with your own. You can:
1. Upload images to https://imgur.com
2. Use the direct image link
3. Or put images in your folder and use local paths: `src="images/your-image.jpg"`

### Change Services
Find the services section in `index.html` and modify:
- Service icons (use https://fontawesome.com/icons)
- Service titles
- Service descriptions

### Change Team Members
Update team names, roles, and photo URLs in the team section.

---

## 📱 TESTING YOUR WEBSITE

### Test Locally (Before Deploying)
1. Download all 3 files to a folder on your computer
2. Double-click `index.html` to open in your browser
3. Make changes and refresh the page to see updates

### Test Responsiveness
1. Open your website in Chrome
2. Press F12 (Developer Tools)
3. Click the phone/tablet icon (top left of dev tools)
4. Select different devices to see how it looks

---

## 🔧 COMMON ISSUES & FIXES

### Issue: Images not loading
- Make sure image URLs are correct and accessible
- Use HTTPS URLs, not HTTP

### Issue: Styles not applying
- Check that `style.css` is in the same folder as `index.html`
- Clear your browser cache (Ctrl + Shift + R)

### Issue: JavaScript not working
- Check that `script.js` is in the same folder as `index.html`
- Open browser console (F12 → Console) to see errors

### Issue: Domain not connecting
- DNS changes take 24-48 hours
- Double-check you entered the DNS records correctly
- Make sure there are no typos in your domain name

---

## 📧 MAKING THE CONTACT FORM WORK

The current form shows a success message but doesn't send emails. To make it actually send emails:

### Option 1: Formspree (Free & Easy)
1. Go to https://formspree.io
2. Sign up and create a new form
3. Copy your form endpoint
4. In `index.html`, change the form tag to:
```html
<form action="https://formspree.io/f/YOUR_ID" method="POST">
```

### Option 2: Netlify Forms (If using Netlify)
Add this attribute to your form:
```html
<form name="contact" netlify>
```

---

## 🎯 NEXT STEPS

1. ✅ Download all 3 files
2. ✅ Test locally by opening index.html
3. ✅ Customize with your company info
4. ✅ Deploy to GitHub Pages or Netlify
5. ✅ Connect your GoDaddy domain
6. ✅ Set up contact form (Formspree)

---

## 💡 TIPS FOR SUCCESS

- Keep your images small (under 500KB) for fast loading
- Test on mobile devices - most visitors use phones
- Update your content regularly
- Add Google Analytics to track visitors
- Consider adding SSL certificate (HTTPS) - GitHub Pages and Netlify do this automatically

---

## 🆘 NEED MORE HELP?

- GitHub Pages Docs: https://docs.github.com/pages
- Netlify Docs: https://docs.netlify.com
- GoDaddy DNS Help: https://www.godaddy.com/help/manage-dns-records-680

Good luck with your IT company website! 🚀
